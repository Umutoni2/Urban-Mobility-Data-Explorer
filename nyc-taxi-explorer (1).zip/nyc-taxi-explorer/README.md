# NYC Taxi Explorer — Urban Mobility Intelligence

A full-stack data analytics dashboard for exploring the NYC Taxi Trip dataset.
Built with **Node.js + SQLite** (single-file backend) and vanilla **HTML/CSS/JavaScript** (single-file frontend).

## Video Walkthrough
**[ADD YOUR VIDEO LINK HERE]**

---

## Project Structure

```
nyc-taxi-explorer/
├── server.js        # Backend: CSV pipeline, SQLite DB, REST API, static server
├── index.html       # Frontend: landing page + interactive dashboard
├── schema.sql       # Database schema reference (auto-applied by server.js on first run)
├── package.json     # Dependencies
├── README.md        # This file
└── train.csv        # ← YOU MUST PLACE THE DATASET HERE (see below)
```

---

## Requirements

- **Node.js** v18 or higher — https://nodejs.org
- **train.csv** from the NYC Taxi Trip Duration dataset

---

## Dataset Setup

1. Download `train.zip` from:
   https://www.kaggle.com/c/nyc-taxi-trip-duration/data

2. Extract `train.csv` and place it in the project root:
   ```
   nyc-taxi-explorer/train.csv
   ```

---

## Installation & Running

```bash
# 1. Navigate into the project folder
cd nyc-taxi-explorer

# 2. Install dependencies (only better-sqlite3)
npm install

# 3. Start the server
npm start
```

The first run will **automatically process train.csv** — this takes **10–20 seconds**
depending on your machine. Subsequent runs are instant (data is cached in `taxi.db`).

4. Open your browser at:
   **http://localhost:3001**

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Server status + trip count |
| GET | `/api/stats` | Quick summary stats for landing page |
| GET | `/api/overview` | All overview charts data (KPIs, hourly, daily, vendor, etc.) |
| GET | `/api/time` | Time pattern data (fare/speed by hour, day-of-week multi) |
| GET | `/api/trips` | Paginated trip table with filters (`?page=&hour=&day=&vendor=&sort=&order=`) |
| GET | `/api/map` | Geo scatter points + hour density + dist-fare scatter |
| GET | `/api/anomalies` | Z-score anomaly detection results |

All endpoints except `/api/trips` respond in **under 100ms** on first call after startup, sourced from the pre-built stats cache.

---

## Database Schema

The schema is normalised across four tables:

```
vendors       — 2 rows — maps vendor_id → company name
time_dims     — ≤1,008 rows — unique (hour, day_of_week, month) combinations
trips         — ~1.3M rows — core fact table with FK references to vendors + time_dims
stats_cache   — ~14 rows — pre-aggregated JSON blobs powering every dashboard chart
meta          — 1 row — ETL state flag
```

**Entity Relationships:**
```
vendors (1) ──────< trips (M)
time_dims (1) ────< trips (M)
```

See `schema.sql` for the full DDL, index definitions, and data cleaning rules.

---

## Features

### Data Pipeline (server.js)
- Streaming CSV parser — handles 1M+ rows without memory issues
- **200,000-row transaction batches** — reduces SQLite commit overhead ~400× vs 500-row batches
- Validates: coordinate bounds (NYC), duration (60s–14400s), passenger count (1–6), distance (0.1–200km), speed (1–150km/h)
- Logs all excluded records with per-reason counts
- Builds `stats_cache` after ETL — all chart aggregations materialised once

### Derived Features
1. **trip_distance_km** — Haversine great-circle distance from GPS coordinates
2. **speed_kmh** — `distance / (duration / 3600)`
3. **fare_estimate** — `$2.50 base + $1.56/km + $0.35/min`

### Algorithm: Z-Score Anomaly Detection (manual, no libraries)
- Computes population mean and variance using the variance shortcut: `Var(X) = E[X²] - (E[X])²`
- Both values derived in a single SQL aggregation — zero additional passes over the data
- Flags trips where |Z| > 2.5 on duration, distance, speed, or fare
- Time complexity: O(n) single pass — Space complexity: O(1)
- All population stats stored in `stats_cache` — anomaly API response is <50ms

### Dashboard Tabs
- **Overview** — 6 KPIs, 4 insight cards, 7 charts
- **Time Patterns** — Hourly fare/speed curves, day-of-week multi-series
- **Trip Explorer** — Filterable/sortable paginated table (server-side, joined through time_dims)
- **Geo Map** — Canvas scatter plot (500 pts, speed-colored), distance-vs-fare scatter
- **Anomalies** — Z-score stats + flagged trips table

---

## Performance Notes

| Metric | Before (v1) | After (v2) |
|--------|------------|------------|
| ETL batch size | 500 rows | 200,000 rows |
| ETL commit count | ~2,600 | ~7 |
| ETL runtime | 45–90s | 10–20s |
| Chart API response | 55–65s | <100ms |
| Schema tables | 2 (flat) | 5 (normalised) |

---

## Troubleshooting

**"train.csv not found"** — Make sure `train.csv` is in the same folder as `server.js`.

**`npm install` fails on better-sqlite3** — Ensure you have Node.js ≥18 and a C++ build toolchain:
- Windows: `npm install --global windows-build-tools`
- macOS: `xcode-select --install`
- Linux: `sudo apt-get install build-essential`

**Port already in use** — Change `const PORT = 3001` in `server.js` to another port.

**Database locked** — Do not run two instances simultaneously. Delete `taxi.db` to re-process.

**Charts show no data** — The stats cache builds after ETL. If you see empty charts on first load, wait for the `[DB] Stats cache ready.` log line, then refresh the browser.

**Want to re-process the CSV** — Delete `taxi.db` and restart the server. The pipeline will re-run automatically.
